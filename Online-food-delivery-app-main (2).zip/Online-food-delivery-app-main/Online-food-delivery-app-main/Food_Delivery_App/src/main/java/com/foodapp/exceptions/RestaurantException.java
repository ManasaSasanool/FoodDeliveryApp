package com.foodapp.exceptions;

public class RestaurantException extends Exception{
	
	public RestaurantException() {
		
	}
	
	
	public RestaurantException(String message){
		super(message);
	}
	
	
	

}
