package com.foodapp.exceptions;

public class CategoryException extends Exception{
	
	public CategoryException() {
		// TODO Auto-generated constructor stub
	}
	
	public CategoryException(String message) {
		super(message);
	}

}
