package com.foodapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodDeliveryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
